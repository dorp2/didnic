<?php

namespace Drupal\bcard_designer\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\JsonResponse;
use Drupal\file\Entity\File;

class CardDesignController extends ControllerBase {

  public function content() {
    $fonts = $this->getFonts();
    $backgrounds = $this->getBackgrounds();

    return [
      '#theme' => 'card_designer',
      '#fonts' => $fonts,
      '#backgrounds' => $backgrounds,
    ];
  }

  private function getFonts() {
    $query = \Drupal::entityQuery('file')
      ->condition('uri', 'public://bcard_designer/fonts/%', 'LIKE');
    $fids = $query->execute();
    $fonts = [];
    foreach ($fids as $fid) {
      $file = File::load($fid);
      $fonts[] = [
        'name' => $file->getFilename(),
        'url' => $file->createFileUrl(),
      ];
    }
    return $fonts;
  }

  private function getBackgrounds() {
    $query = \Drupal::entityQuery('file')
      ->condition('uri', 'public://bcard_designer/backgrounds/%', 'LIKE');
    $fids = $query->execute();
    $backgrounds = [];
    foreach ($fids as $fid) {
      $file = File::load($fid);
      $backgrounds[] = [
        'name' => $file->getFilename(),
        'url' => $file->createFileUrl(),
      ];
    }
    return $backgrounds;
  }

  public function getAssets() {
    $fonts = $this->getFonts();
    $backgrounds = $this->getBackgrounds();
    return new JsonResponse([
      'fonts' => $fonts,
      'backgrounds' => $backgrounds,
    ]);
  }
}