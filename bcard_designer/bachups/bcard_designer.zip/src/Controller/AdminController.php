<?php

namespace Drupal\bcard_designer\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
 * Controller for managing card designs.
 */
class AdminController extends ControllerBase {

  /**
   * The entity type manager.
   *
   * @var \Drupal\Core\Entity\EntityTypeManagerInterface
   */
  protected $entityTypeManager;

  /**
   * Constructs a new AdminController object.
   */
  public function __construct(EntityTypeManagerInterface $entity_type_manager) {
    $this->entityTypeManager = $entity_type_manager;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('entity_type.manager')
    );
  }

  /**
   * Lists all card designs.
   */
  public function listDesigns() {
    $designs = $this->entityTypeManager->getStorage('card_design')->loadMultiple();
    $design_list = [];
    foreach ($designs as $design) {
      $design_list[] = [
        'id' => $design->id(),
        'name' => $design->label(),
        'path' => $design->design_file->entity ? $this->entityTypeManager->getStorage('file')->load($design->design_file->target_id)->createFileUrl() : '',
      ];
    }

    return [
      '#theme' => 'admin_card_designs',
      '#designs' => $design_list,
    ];
  }

}