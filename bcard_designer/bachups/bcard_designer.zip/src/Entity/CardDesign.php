<?php

namespace Drupal\bcard_designer\Entity;

use Drupal\Core\Entity\ContentEntityBase;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Field\BaseFieldDefinition;

/**
 * Defines the Card Design entity.
 *
 * @ContentEntityType(
 *   id = "card_design",
 *   label = @Translation("Card Design"),
 *   base_table = "card_design",
 *   entity_keys = {
 *     "id" = "id",
 *     "label" = "name",
 *     "uuid" = "uuid",
 *   },
 *   handlers = {
 *     "form" = {
 *       "default" = "Drupal\bcard_designer\Form\CardDesignForm",
 *       "delete" = "Drupal\bcard_designer\Form\CardDesignDeleteForm",
 *     },
 *     "route_provider" = {
 *       "html" = "Drupal\Core\Entity\Routing\AdminHtmlRouteProvider",
 *     },
 *   },
 *   links = {
 *     "canonical" = "/admin/config/bcard-designer/{card_design}",
 *     "add-form" = "/admin/config/bcard-designer/add",
 *     "edit-form" = "/admin/config/bcard-designer/{card_design}/edit",
 *     "delete-form" = "/admin/config/bcard-designer/{card_design}/delete",
 *   },
 * )
 */
class CardDesign extends ContentEntityBase {

  /**
   * {@inheritdoc}
   */
  public static function baseFieldDefinitions(EntityTypeInterface $entity_type) {
    $fields = parent::baseFieldDefinitions($entity_type);

    $fields['name'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Name'))
      ->setRequired(TRUE)
      ->setDisplayOptions('form', [
        'type' => 'string_textfield',
        'weight' => -5,
      ])
      ->setDisplayConfigurable('form', TRUE);

    $fields['design_file'] = BaseFieldDefinition::create('file')
      ->setLabel(t('Design File'))
      ->setRequired(TRUE)
      ->setSettings([
        'file_directory' => 'designs',
        'file_extensions' => 'png jpg jpeg',
      ])
      ->setDisplayOptions('form', [
        'type' => 'file',
        'weight' => 0,
      ])
      ->setDisplayConfigurable('form', TRUE);

    return $fields;
  }

}