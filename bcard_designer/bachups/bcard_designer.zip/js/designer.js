(function ($, Drupal) {
  'use strict';

  Drupal.behaviors.bcardDesigner = {
    attach: function (context) {
      var canvas = new fabric.Canvas('c', { backgroundColor: '#f0fc0a' });
      var currentFace = 'front';

      window._Front_Face = function () {
        currentFace = 'front';
        canvas.clear();
        canvas.setBackgroundColor('#f0fc0a', canvas.renderAll.bind(canvas));
      };

      window._Back_Face = function () {
        currentFace = 'back';
        canvas.clear();
        canvas.setBackgroundColor('#ffffff', canvas.renderAll.bind(canvas));
      };

      window._Rect_Create = function () {
        var rect = new fabric.Rect({
          left: 100,
          top: 100,
          fill: 'red',
          width: 50,
          height: 50,
        });
        canvas.add(rect);
      };

      window._Circle_Create = function () {
        var circle = new fabric.Circle({
          left: 100,
          top: 100,
          fill: 'blue',
          radius: 25,
        });
        canvas.add(circle);
      };

      window._Triangle_Create = function () {
        var triangle = new fabric.Triangle({
          left: 100,
          top: 100,
          fill: 'green',
          width: 50,
          height: 50,
        });
        canvas.add(triangle);
      };

      window._Text_Create = function () {
        var text = new fabric.Text('متن نمونه', {
          left: 100,
          top: 100,
          fontFamily: 'Tahoma',
          fontSize: 20,
        });
        canvas.add(text);
      };

      window._Color_Change = function () {
        var activeObject = canvas.getActiveObject();
        if (activeObject) {
          activeObject.set('fill', $('#colordesigner').val());
          canvas.renderAll();
        }
      };

      $('#Delete_item', context).on('click', function () {
        var activeObject = canvas.getActiveObject();
        if (activeObject) {
          canvas.remove(activeObject);
        }
      });

      window._Bring_Forward = function () {
        var activeObject = canvas.getActiveObject();
        if (activeObject) {
          canvas.bringToFront(activeObject);
        }
      };

      window._Backwards = function () {
        var activeObject = canvas.getActiveObject();
        if (activeObject) {
          canvas.sendToBack(activeObject);
        }
      };

      window._Bring_Forward_One_Layer = function () {
        var activeObject = canvas.getActiveObject();
        if (activeObject) {
          canvas.bringForward(activeObject);
        }
      };

      window._Backwards_One_Layer = function () {
        var activeObject = canvas.getActiveObject();
        if (activeObject) {
          canvas.sendBackwards(activeObject);
        }
      };

      window._Change_Font = function () {
        var activeObject = canvas.getActiveObject();
        if (activeObject && activeObject.type === 'text') {
          activeObject.set('fontFamily', $('#fontFamily').val());
          canvas.renderAll();
        }
      };

      window._Change_Custom_Font = function () {
        var fontUrl = document.getElementById('customFontFamily').value;
        var fontName = document.getElementById('customFontFamily').selectedOptions[0].text;

        var newStyle = document.createElement('style');
        newStyle.appendChild(document.createTextNode(`
          @font-face {
            font-family: '${fontName}';
            src: url('${fontUrl}') format('truetype');
          }
        `));
        document.head.appendChild(newStyle);

        var activeObject = canvas.getActiveObject();
        if (activeObject && activeObject.type === 'text') {
          activeObject.set('fontFamily', fontName);
          canvas.renderAll();
        }
      };
      window._Change_FontSize = function () {
        var activeObject = canvas.getActiveObject();
        if (activeObject && activeObject.type === 'text') {
          activeObject.set('fontSize', parseInt($('#fontSize').val()));
          canvas.renderAll();
        }
      };

      window._Text_Bold = function () {
        var activeObject = canvas.getActiveObject();
        if (activeObject && activeObject.type === 'text') {
          activeObject.set('fontWeight', activeObject.fontWeight === 'bold' ? 'normal' : 'bold');
          canvas.renderAll();
        }
      };

      window._Text_Italic = function () {
        var activeObject = canvas.getActiveObject();
        if (activeObject && activeObject.type === 'text') {
          activeObject.set('fontStyle', activeObject.fontStyle === 'italic' ? 'normal' : 'italic');
          canvas.renderAll();
        }
      };

      window._Text_Underline = function () {
        var activeObject = canvas.getActiveObject();
        if (activeObject && activeObject.type === 'text') {
          activeObject.set('underline', !activeObject.underline);
          canvas.renderAll();
        }
      };

      $('#ImageData', context).on('change', function (e) {
        var file = e.target.files[0];
        var reader = new FileReader();
        reader.onload = function (f) {
          var data = f.target.result;
          fabric.Image.fromURL(data, function (img) {
            img.scale(0.5);
            canvas.add(img);
          });
        };
        reader.readAsDataURL(file);
      });

      $('#ImageBackGroundData', context).on('change', function (e) {
        var file = e.target.files[0];
        var reader = new FileReader();
        reader.onload = function (f) {
          var data = f.target.result;
          canvas.setBackgroundImage(data, canvas.renderAll.bind(canvas), {
            scaleX: canvas.width / 850,
            scaleY: canvas.height / 550,
          });
        };
        reader.readAsDataURL(file);
      });

      window._Delete_Background_Image = function () {
        canvas.setBackgroundImage(null, canvas.renderAll.bind(canvas));
      };

      window._Change_Background = function () {
        var bgUrl = document.getElementById('backgroundSelect').value;
        if (bgUrl) {
          fabric.Image.fromURL(bgUrl, function(img) {
            canvas.setBackgroundImage(img, canvas.renderAll.bind(canvas), {
              scaleX: canvas.width / img.width,
              scaleY: canvas.height / img.height
            });
          });
        } else {
          canvas.setBackgroundImage(null, canvas.renderAll.bind(canvas));
        }
      };

      $('#file_save', context).on('click', function () {
        canvas.renderAll();
        canvas.getElement().toBlob(function (blob) {
          saveAs(blob, 'business_card.png');
        });
      });
    }
  };
})(jQuery, Drupal);